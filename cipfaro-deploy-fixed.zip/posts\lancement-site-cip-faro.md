# Lancement du site CIP FARO

Bienvenue sur le blog d'information du CIP FARO. Voici les dernières nouvelles et ressources.

Nous sommes heureux de lancer le blog d'information du CIP FARO.

Ici vous trouverez des actualités, des ressources pour les formations, et des mises à jour importantes.
