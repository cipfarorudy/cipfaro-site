import{r as c,j as e,L as n}from"./vendor-CPnXDLFs.js";import{f as d}from"./formations-XVPXz53Z.js";function b(){const[s,h]=c.useState({formations:{total:d.length,populaires:[],taux_completion:0},recrutement:{candidatures:0,offres:0,matchings:0,taux_matching:0},visiteurs:{total_today:0,total_month:0,pages_populaires:[],taux_conversion:0},notifications:[]}),[i,p]=c.useState("7j");c.useEffect(()=>{(async()=>{const t={formations:{total:d.length,populaires:d.sort(()=>Math.random()-.5).slice(0,5).map(r=>({titre:r.titre,vues:Math.floor(Math.random()*500)+50,inscriptions:Math.floor(Math.random()*30)+5})),taux_completion:87.5},recrutement:{candidatures:Math.floor(Math.random()*150)+200,offres:Math.floor(Math.random()*50)+75,matchings:Math.floor(Math.random()*80)+120,taux_matching:78.3},visiteurs:{total_today:Math.floor(Math.random()*200)+150,total_month:Math.floor(Math.random()*5e3)+8e3,pages_populaires:[{page:"Formations",vues:Math.floor(Math.random()*1e3)+500},{page:"Recrutement",vues:Math.floor(Math.random()*800)+300},{page:"Accueil",vues:Math.floor(Math.random()*1200)+800},{page:"Contact",vues:Math.floor(Math.random()*400)+200},{page:"Financement",vues:Math.floor(Math.random()*600)+250}],taux_conversion:12.8},notifications:[{id:1,type:"success",titre:"Nouveau matching réussi",message:'Un candidat formé en "Développement Web" a été mis en relation avec "TechCorp Guadeloupe"',date:new Date(Date.now()-18e5)},{id:2,type:"info",titre:"Nouvelle candidature",message:'Candidature reçue pour la formation "Bureautique Avancée"',date:new Date(Date.now()-72e5)},{id:3,type:"warning",titre:"Formation bientôt complète",message:`La formation "Excel Perfectionnement" n'a plus que 2 places disponibles`,date:new Date(Date.now()-144e5)}]};h(t)})()},[i]);const u=a=>{const r=new Date-a,o=Math.floor(r/6e4),l=Math.floor(r/36e5),m=Math.floor(r/864e5);return o<60?`Il y a ${o} min`:l<24?`Il y a ${l}h`:`Il y a ${m} jour${m>1?"s":""}`},x=()=>{const a={date:new Date().toISOString(),periode:i,stats:s},t=new Blob([JSON.stringify(a,null,2)],{type:"application/json"}),r=URL.createObjectURL(t),o=document.createElement("a");o.href=r,o.download=`cipfaro-stats-${new Date().toISOString().split("T")[0]}.json`,o.click(),URL.revokeObjectURL(r)};return e.jsxs("div",{className:"dashboard",children:[e.jsx("style",{children:`
        .dashboard {
          padding: 2rem;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          min-height: 100vh;
        }
        .dashboard-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 2rem;
          color: white;
        }
        .dashboard-title {
          font-size: 2.5rem;
          font-weight: bold;
          margin: 0;
        }
        .dashboard-actions {
          display: flex;
          gap: 1rem;
        }
        .period-selector {
          background: rgba(255,255,255,0.2);
          border: 1px solid rgba(255,255,255,0.3);
          border-radius: 0.5rem;
          padding: 0.5rem 1rem;
          color: white;
        }
        .export-btn {
          background: #10b981;
          color: white;
          border: none;
          border-radius: 0.5rem;
          padding: 0.5rem 1rem;
          cursor: pointer;
          font-weight: 500;
        }
        .export-btn:hover {
          background: #059669;
        }
        .stats-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
          gap: 1.5rem;
          margin-bottom: 2rem;
        }
        .stat-card {
          background: rgba(255,255,255,0.95);
          border-radius: 1rem;
          padding: 1.5rem;
          box-shadow: 0 10px 25px rgba(0,0,0,0.1);
          border-left: 4px solid #3b82f6;
        }
        .stat-card.success { border-left-color: #10b981; }
        .stat-card.warning { border-left-color: #f59e0b; }
        .stat-card.info { border-left-color: #8b5cf6; }
        .stat-card h3 {
          margin: 0 0 1rem 0;
          font-size: 1.25rem;
          color: #1f2937;
        }
        .stat-number {
          font-size: 2.5rem;
          font-weight: bold;
          color: #3b82f6;
          margin-bottom: 0.5rem;
        }
        .stat-label {
          color: #6b7280;
          font-size: 0.875rem;
        }
        .stat-list {
          list-style: none;
          padding: 0;
          margin: 0;
        }
        .stat-list li {
          display: flex;
          justify-content: space-between;
          padding: 0.5rem 0;
          border-bottom: 1px solid #e5e7eb;
        }
        .stat-list li:last-child {
          border-bottom: none;
        }
        .notifications-section {
          background: rgba(255,255,255,0.95);
          border-radius: 1rem;
          padding: 1.5rem;
          box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        }
        .notification {
          display: flex;
          align-items: flex-start;
          gap: 1rem;
          padding: 1rem;
          border-radius: 0.5rem;
          margin-bottom: 1rem;
          border-left: 4px solid #3b82f6;
        }
        .notification.success { 
          background: #ecfdf5; 
          border-left-color: #10b981; 
        }
        .notification.warning { 
          background: #fffbeb; 
          border-left-color: #f59e0b; 
        }
        .notification.info { 
          background: #f3f4f6; 
          border-left-color: #6b7280; 
        }
        .notification-icon {
          font-size: 1.5rem;
        }
        .notification-content h4 {
          margin: 0 0 0.5rem 0;
          font-size: 1rem;
          color: #1f2937;
        }
        .notification-content p {
          margin: 0 0 0.5rem 0;
          color: #6b7280;
          font-size: 0.875rem;
        }
        .notification-time {
          font-size: 0.75rem;
          color: #9ca3af;
        }
        .quick-actions {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
          gap: 1rem;
          margin-top: 2rem;
        }
        .action-card {
          background: rgba(255,255,255,0.95);
          border-radius: 1rem;
          padding: 1.5rem;
          text-align: center;
          text-decoration: none;
          color: #1f2937;
          box-shadow: 0 4px 15px rgba(0,0,0,0.1);
          transition: transform 0.2s;
        }
        .action-card:hover {
          transform: translateY(-2px);
          box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        }
        .action-icon {
          font-size: 2rem;
          margin-bottom: 0.5rem;
          display: block;
        }
      `}),e.jsxs("div",{className:"dashboard-header",children:[e.jsx("h1",{className:"dashboard-title",children:"📊 Tableau de bord CIP FARO"}),e.jsxs("div",{className:"dashboard-actions",children:[e.jsxs("select",{className:"period-selector",value:i,onChange:a=>p(a.target.value),children:[e.jsx("option",{value:"24h",children:"Dernières 24h"}),e.jsx("option",{value:"7j",children:"7 derniers jours"}),e.jsx("option",{value:"30j",children:"30 derniers jours"})]}),e.jsx("button",{className:"export-btn",onClick:x,children:"📊 Exporter les données"})]})]}),e.jsxs("div",{className:"stats-grid",children:[e.jsxs("div",{className:"stat-card",children:[e.jsx("h3",{children:"📚 Formations"}),e.jsx("div",{className:"stat-number",children:s.formations.total}),e.jsx("div",{className:"stat-label",children:"Formations disponibles"}),e.jsxs("div",{style:{marginTop:"1rem"},children:[e.jsx("strong",{children:"Taux de completion:"})," ",s.formations.taux_completion,"%"]})]}),e.jsxs("div",{className:"stat-card success",children:[e.jsx("h3",{children:"🎯 Recrutement"}),e.jsx("div",{className:"stat-number",children:s.recrutement.matchings}),e.jsx("div",{className:"stat-label",children:"Matchings réussis"}),e.jsxs("div",{style:{marginTop:"1rem"},children:[e.jsxs("div",{children:["Candidatures: ",e.jsx("strong",{children:s.recrutement.candidatures})]}),e.jsxs("div",{children:["Offres: ",e.jsx("strong",{children:s.recrutement.offres})]}),e.jsxs("div",{children:["Taux de matching: ",e.jsxs("strong",{children:[s.recrutement.taux_matching,"%"]})]})]})]}),e.jsxs("div",{className:"stat-card info",children:[e.jsx("h3",{children:"👥 Visiteurs"}),e.jsx("div",{className:"stat-number",children:s.visiteurs.total_today}),e.jsx("div",{className:"stat-label",children:"Visiteurs aujourd'hui"}),e.jsxs("div",{style:{marginTop:"1rem"},children:[e.jsxs("div",{children:["Ce mois: ",e.jsx("strong",{children:s.visiteurs.total_month.toLocaleString()})]}),e.jsxs("div",{children:["Taux de conversion: ",e.jsxs("strong",{children:[s.visiteurs.taux_conversion,"%"]})]})]})]}),e.jsxs("div",{className:"stat-card",children:[e.jsx("h3",{children:"🔥 Formations populaires"}),e.jsx("ul",{className:"stat-list",children:s.formations.populaires.map((a,t)=>e.jsxs("li",{children:[e.jsx("span",{children:a.titre}),e.jsxs("span",{children:[e.jsx("strong",{children:a.vues})," vues"]})]},t))})]}),e.jsxs("div",{className:"stat-card",children:[e.jsx("h3",{children:"📈 Pages populaires"}),e.jsx("ul",{className:"stat-list",children:s.visiteurs.pages_populaires.map((a,t)=>e.jsxs("li",{children:[e.jsx("span",{children:a.page}),e.jsxs("span",{children:[e.jsx("strong",{children:a.vues})," vues"]})]},t))})]})]}),e.jsxs("div",{className:"notifications-section",children:[e.jsx("h3",{children:"🔔 Notifications récentes"}),s.notifications.map(a=>e.jsxs("div",{className:`notification ${a.type}`,children:[e.jsx("span",{className:"notification-icon",children:a.type==="success"?"✅":a.type==="warning"?"⚠️":"ℹ️"}),e.jsxs("div",{className:"notification-content",children:[e.jsx("h4",{children:a.titre}),e.jsx("p",{children:a.message}),e.jsx("div",{className:"notification-time",children:u(a.date)})]})]},a.id))]}),e.jsxs("div",{className:"quick-actions",children:[e.jsxs(n,{to:"/formations",className:"action-card",children:[e.jsx("span",{className:"action-icon",children:"📚"}),e.jsx("div",{children:"Gérer les formations"})]}),e.jsxs(n,{to:"/recrutement",className:"action-card",children:[e.jsx("span",{className:"action-icon",children:"🎯"}),e.jsx("div",{children:"Espace recrutement"})]}),e.jsxs(n,{to:"/contact",className:"action-card",children:[e.jsx("span",{className:"action-icon",children:"📞"}),e.jsx("div",{children:"Messages & contacts"})]}),e.jsxs(n,{to:"/sitemap",className:"action-card",children:[e.jsx("span",{className:"action-icon",children:"🗺️"}),e.jsx("div",{children:"Outils SEO"})]}),e.jsxs("a",{href:"https://analytics.google.com",target:"_blank",rel:"noopener noreferrer",className:"action-card",children:[e.jsx("span",{className:"action-icon",children:"📊"}),e.jsx("div",{children:"Google Analytics"})]}),e.jsxs("a",{href:"https://search.google.com/search-console",target:"_blank",rel:"noopener noreferrer",className:"action-card",children:[e.jsx("span",{className:"action-icon",children:"🔍"}),e.jsx("div",{children:"Search Console"})]})]})]})}export{b as default};
