# Nouvelle formation: Développement web (septembre)

Une nouvelle session de formation en développement web commence en octobre.

Détails de la formation: durée 6 semaines, public visé, prérequis et modalités d'inscription.
