import{k as t}from"./vendor-CPnXDLFs.js";const r={serviceId:"service_xxxxxxxxx",templateId:{candidatureRecue:"template_test_candidature",offreRecue:"template_test_offre",matching:"template_test_matching",inscription:"template_test_inscription",devis:"template_test_devis"},publicKey:"xxxxxxxxxxxxxxxxxx"};function a(){t.init(r.publicKey),console.log("📧 Service email initialisé")}const i={candidatureRecue:{subject:"✅ Votre candidature CIP FARO a été reçue",template:e=>`
Bonjour ${e.prenom} ${e.nom},

Nous avons bien reçu votre candidature pour ${e.formation||"un poste"} !

📋 **Récapitulatif :**
- Formation : ${e.formation}
- Email : ${e.email}
- Téléphone : ${e.telephone}
- Disponibilité : ${e.disponibilite}

🎯 **Prochaines étapes :**
1. Analyse de votre profil (24-48h)
2. Mise en relation avec les entreprises correspondantes
3. Contact direct des entreprises intéressées

📞 **Contact :** Si vous avez des questions, n'hésitez pas à nous contacter au 0690570846.

Cordialement,
L'équipe CIP FARO
secretariat@cipfaro-formations.com
    `},offreRecue:{subject:"🏢 Votre offre d'emploi CIP FARO a été publiée",template:e=>`
Bonjour ${e.prenom} ${e.nom},

Votre offre d'emploi a été publiée avec succès sur notre plateforme !

💼 **Détails de l'offre :**
- Entreprise : ${e.nomEntreprise}
- Poste : ${e.postePropose}
- Type de contrat : ${e.typeContrat}
- Localisation : ${e.localisationPoste}
- Formations ciblées : ${e.formationsCiblees?.join(", ")||"Non spécifiées"}

🎯 **Matching automatique :**
Nous analysons déjà notre base de candidats pour vous proposer les profils les plus pertinents.

📊 **Statistiques moyennes CIP FARO :**
- Délai moyen de proposition : 48h
- Taux de matching : 85%
- Satisfaction entreprises : 4.8/5

Vous recevrez un email dès qu'un candidat correspondant sera identifié.

Cordialement,
L'équipe CIP FARO
secretariat@cipfaro-formations.com
    `},matchingDetecte:{subject:"🎯 Nouveau candidat correspondant à votre offre !",template:e=>`
Bonjour ${e.entrepriseContact},

Excellente nouvelle ! Un candidat formé par CIP FARO correspond à votre recherche.

👤 **Profil candidat :**
- Formation suivie : ${e.candidatFormation}
- Expérience : ${e.candidatExperience}
- Disponibilité : ${e.candidatDisponibilite}
- Score de correspondance : ${e.matchScore}%

💼 **Votre recherche :**
- Poste : ${e.posteRecherche}
- Entreprise : ${e.entreprise}

🤝 **Pour prendre contact :**
Email du candidat : ${e.candidatEmail}
Téléphone : ${e.candidatTelephone}

📎 **CV disponible** : Le CV sera transmis après accord mutuel.

✨ **Pourquoi ce matching ?**
${e.raisonMatching||"Formation parfaitement alignée avec vos besoins"}

Cordialement,
L'équipe CIP FARO
secretariat@cipfaro-formations.com
    `},inscriptionConfirmee:{subject:"📚 Inscription confirmée - Formation CIP FARO",template:e=>`
Bonjour ${e.prenom} ${e.nom},

Votre préinscription à la formation "${e.formation}" est confirmée !

📅 **Informations formation :**
- Formation : ${e.formation}
- Durée : ${e.duree}
- Modalités : ${e.modalites}
- Début prévu : ${e.dateDebut||"À définir selon planning"}

💰 **Financement :**
${e.financement||"Nous vous accompagnons dans les démarches de financement (CPF, Pôle Emploi, etc.)"}

📋 **Prochaines étapes :**
1. Validation des prérequis et du financement
2. Convocation pour entretien de motivation (si nécessaire)
3. Confirmation des dates de formation
4. Envoi du dossier d'inscription complet

🎓 **Accès Moodle :** Vos identifiants de connexion vous seront communiqués 48h avant le début de la formation.

Nous vous recontacterons sous 48h pour finaliser votre dossier.

Cordialement,
L'équipe CIP FARO
secretariat@cipfaro-formations.com
    `}};async function m(e){try{const o={to_email:e.email,to_name:`${e.prenom} ${e.nom}`,from_name:"CIP FARO",message:i.candidatureRecue.template(e),subject:i.candidatureRecue.subject},n=await t.send(r.serviceId,r.templateId.candidatureRecue,o);return console.log("📧 Email candidature envoyé:",n),{success:!0,messageId:n.text}}catch(o){return console.error("❌ Erreur envoi email candidature:",o),{success:!1,error:o.message}}}async function u(e){try{const o={to_email:e.email,to_name:`${e.prenom} ${e.nom}`,from_name:"CIP FARO",message:i.offreRecue.template(e),subject:i.offreRecue.subject},n=await t.send(r.serviceId,r.templateId.offreRecue,o);return console.log("📧 Email offre envoyé:",n),{success:!0,messageId:n.text}}catch(o){return console.error("❌ Erreur envoi email offre:",o),{success:!1,error:o.message}}}async function l(e){try{const o={to_email:e.email,to_name:`${e.prenom} ${e.nom}`,from_name:"CIP FARO",message:i.inscriptionConfirmee.template(e),subject:i.inscriptionConfirmee.subject},n=await t.send(r.serviceId,r.templateId.inscription,o);return console.log("📧 Email inscription envoyé:",n),{success:!0,messageId:n.text}}catch(o){return console.error("❌ Erreur envoi email inscription:",o),{success:!1,error:o.message}}}function s(){const e=r.publicKey!=="your_public_key_here";return console.log("✅ Configuration email OK"),e}s();export{u as a,m as b,l as e,a as i};
